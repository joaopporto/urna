from tkinter import image_names
from graphics import *

arq = open("urna.csv","r")
dados = arq.read()
lista = dados.split("\n")
lista = lista[:-1]
for ind in range(len(lista)):
    lista[ind] = lista[ind].split(";")

def main():
    win = GraphWin("Urna", 1280, 720)
    urna = Rectangle(Point(10, 10), Point(1200, 640))
    urna.draw(win)
    quadrado = Rectangle(Point(1170, 40), Point(750, 610))
    quadrado.draw(win)
    tela = Image(Point(20, 20), "tela.png")
    tela.draw(win)
    win.getMouse()
    win.close()

main()